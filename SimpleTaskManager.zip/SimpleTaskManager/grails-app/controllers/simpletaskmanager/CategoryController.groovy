package simpletaskmanager

class CategoryController {

    def index() { }
}
