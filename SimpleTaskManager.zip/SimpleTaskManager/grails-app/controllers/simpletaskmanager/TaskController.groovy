package simpletaskmanager

class TaskController {

    def index() {
        def tasks = Task.findAll()
        [tasks: tasks]
    }

    def create() {
        def categories = Category.list()
        render(view:'create', model:[categories:categories])
    }

    def save() {
        def task = new Task(params)
        if (task.save(flush: true)) {
            flash.message = "Task saved successfully!"
            redirect(action: "index")
        } else {
            flash.message = "Error saving task"
            render(view: "create", model: [task: task])
        }
    }

    def edit(Long id) {
        def task = Task.get(id)
        if (!task) {
            flash.message = "Task not found"
            redirect(action: "index")
        }
        render(view: "edit", model: [task: task])
    }

    def update(Long id) {
        def task = Task.get(id)

        if (task) {

            // task.title = params.title
            // task.description = params.description
            task.properties = params

            task.save(flush: true)
            flash.message = "task updated successfully!"
        } else {
            flash.message = "task not found!"
        }
        redirect(action: "index")
    }

    def delete(Long id) {
        def task = Task.get(id)

        if (task) {
            task.delete(flush: true)
            flash.message = "Product deleted successfully!"
        } else {
            flash.message = "Product not found!"
        }
        redirect(action: "index")
    }

    def toggleComplete(Long id) {
        def task = Task.get(id)
        if (task) {
            task.completed = !task.completed  // Toggle completion status
            task.save(flush: true)
        }
        redirect(action: "index")
    }

    def search() {

    }

    def search_task(){
        String query = params.query?.trim()

        def tasks = []
        if (query) {
            tasks = Task.findAllByTitleIlike("%${query}%")  // Case-insensitive search
        }

        render(view: "search", model: [tasks: tasks])
    }


}
