package simpletaskmanager

class Category {
    String category_name

    static constraints = {
    }
}
