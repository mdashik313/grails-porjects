package simpletaskmanager

class Task {
    String title
    String description
    Boolean completed = false
    Integer priority

    static constraints = {
    }
}
