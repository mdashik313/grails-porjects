package pos
import java.text.SimpleDateFormat
import java.util.TimeZone

class ProductController {

    def index() {
        def products = Product.list()  // Fetch all products
        def groupedProducts = products.groupBy{it.product_group}
        [groupedProducts:groupedProducts, products:products]
    }

    def create(){

    }

    def save(){
        def product = new Product(params)

        def date = new Date()  // Current date and time
        def sdf = new SimpleDateFormat("MMMM d, yyyy h:mm:ss a z") // Format
        sdf.setTimeZone(TimeZone.getTimeZone("Asia/Dhaka")) // Set to Bangladesh Time (BDT)
        def formattedDate = sdf.format(date)
        
        product.created_date = formattedDate

        if(product.save(flush:true)){
            redirect(action:"index")
        }
    }

    def view_details(){
        
    }

    def edit() {

    }

    def delete() {

    }
}
